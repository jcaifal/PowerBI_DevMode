# PowerBI_DevMode

aca testearemos nuestro modo DEV en Power BI
